TO SSH INTO SERVER:
eb ssh
--
source /opt/python/run/venv/bin/activate <p>
source /opt/python/current/env<p>
cd /opt/python/current/app<p>
python manage.py (commands)